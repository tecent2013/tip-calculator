//
//  ViewController.m
//  tipsplit
//
//  Created by ITP on 9/26/16.
//  Copyright © 2016 WenhanFan. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic)   float bill;
@property (nonatomic)   float taxPercent;
@property (nonatomic)   float taxAmount;
@property (nonatomic)   float tipPercent;
@property (nonatomic)   float totalForTip;
@property (nonatomic)   float tipValue;
@property (nonatomic)   float totalWithTip;
@property (nonatomic)   float totalPerPerson;
@property int splitNumber;
@property bool includeTax;

@property (weak, nonatomic) IBOutlet UISlider *mySlider;

@property (weak, nonatomic) IBOutlet UITextField *getBill;

@property (weak, nonatomic) IBOutlet UILabel *tipPercentLabel;

@property (weak, nonatomic) IBOutlet UISegmentedControl *segValue;

@property (weak, nonatomic) IBOutlet UISwitch *tipIncludeTaxValue;

@property (weak, nonatomic) IBOutlet UILabel *evenSplitLabel;

@property (weak, nonatomic) IBOutlet UIStepper *stepper;

@property (weak, nonatomic) IBOutlet UILabel *finalTaxLabel;

@property (weak, nonatomic) IBOutlet UILabel *finalTotalForTipLabel;

@property (weak, nonatomic) IBOutlet UILabel *finalTipValueLabel;

@property (weak, nonatomic) IBOutlet UILabel *totalPerPersonLabel;

@property (weak, nonatomic) IBOutlet UILabel *finalTotalWithTipLabel;


@end

@implementation ViewController
- (IBAction)getBillTF:(id)sender {
    self.bill=[self.getBill.text floatValue];
    [self updateValues];
}


- (IBAction)segChanged:(id)sender {
    switch (self.segValue.selectedSegmentIndex){
        case 0:
            self.taxPercent = 0.075;
            break;
        case 1:
            self.taxPercent = 0.08;
            break;
        case 2:
            self.taxPercent = 0.085;
            break;
        case 3:
            self.taxPercent = 0.09;
            break;
        case 4:
            self.taxPercent = 0.095;
            break;
    }
    [self updateValues];
}

- (IBAction)includeTax:(id)sender {
    self.includeTax = self.tipIncludeTaxValue.isOn;
    [self updateValues];
}

- (IBAction)sliderChanged:(id)sender {
    self.tipPercent = self.mySlider.value/100;
    self.tipPercentLabel.text = [NSString stringWithFormat:@"%.02f %%",self.mySlider.value];
    [self updateValues];
}

- (IBAction)stepperChanged:(id)sender {
    int stepperValue = (int)self.stepper.value;
    self.splitNumber = stepperValue;
    self.evenSplitLabel.text = [NSString stringWithFormat:@"%d",_splitNumber];
    [self updateValues];
}

- (IBAction)clearAllPressed:(id)sender {
    [self clearAll];
}
- (IBAction)backgroundTouched:(id)sender {
    [self.getBill resignFirstResponder];
}

-(void)setDefaultValues{
    self.bill = 0;
    self.taxPercent = 0;
    self.taxAmount = 0;
    self.tipPercent = 0;
    self.totalForTip = 0;
    self.tipValue = 0;
    self.totalWithTip = 0;
    _totalPerPerson = 0;
    self.splitNumber = 1;
    _includeTax = false;
}

-(void)updateValues{
    self.taxAmount = self.bill* self.taxPercent;
    if(self.includeTax){
        self.totalForTip = self.bill + self.taxAmount;
    }
    else{
        self.totalForTip = self.bill;
    }
    self.tipValue = self.totalForTip*_tipPercent;
    _totalWithTip = _bill + _tipValue + _taxAmount;
    _totalPerPerson = _totalWithTip/_splitNumber;
    printf("%f \n %f \n %f \n %f \n %f \n %f \n %f",_bill,_taxPercent,_taxAmount
         ,_taxPercent,_tipValue,_tipPercent,_totalWithTip);
    
    _finalTaxLabel.text = [NSString stringWithFormat:@"%.02f", _taxAmount];
    
    _finalTotalForTipLabel.text = [NSString stringWithFormat:@"%.02f",_totalForTip];
    _finalTipValueLabel.text = [NSString stringWithFormat:@"%.02f",_tipValue];
    _finalTotalWithTipLabel.text = [NSString stringWithFormat:@"%.02f",_totalWithTip];
    _totalPerPersonLabel.text = [NSString stringWithFormat:@"%.02f",_totalPerPerson];
    
}

-(void) clearAll{
    [self setDefaultValues];
    _getBill.text = @"";
   // [_segValue select
    [_tipIncludeTaxValue setOn:false];
    [_mySlider setValue:0];
    _stepper.value = 1;
    _finalTaxLabel.text = @"0";
    _finalTotalForTipLabel.text = @"0";
    _finalTipValueLabel.text = @"0";
    _finalTotalWithTipLabel.text = @"0";
    _evenSplitLabel.text = @"1";
    _totalPerPersonLabel.text = @"0";
    _segValue.selectedSegmentIndex = UISegmentedControlNoSegment;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setDefaultValues];
    //[self ]
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
